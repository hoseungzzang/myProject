import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MainGui extends JFrame {

	private JPanel contentPane;
	private JTextField pointField;
	private JTextField idField;
	private JTable bookTable;
	private JTable cartTable;
	private JTextField totallField;
	private JTextField searchField;

	private final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver"; //����̹�
	private final String DB_URL = "jdbc:mysql://localhost/booksell?serverTimezone = UTC"; //������ DB ����
		
	private final String USER_NAME = "Lee"; //DB�� ������ ����� �̸��� ����� ����
	private final String PASSWORD = "1111"; //������� ��й�ȣ�� ����� ����
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainGui frame = new MainGui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainGui() {
		
		setTitle("\uC120\uBB38 \uC911\uACE0\uCC45 \uC2DC\uC7A5");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1038, 664);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setResizable(false);
		
		JButton btnSale = new JButton("\uD310\uB9E4\uD558\uAE30");//�ǸŹ�ư
		btnSale.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {//�ǸŹ�ưŬ���̺�Ʈ
				SellGui frame = new SellGui();
				frame.setVisible(true);
			}
		});
		btnSale.setBounds(27, 15, 125, 29);
		contentPane.add(btnSale);
		
		JButton btnSuggestions = new JButton("\uAC74\uC758\uD558\uAE30");//���ǹ�ư
		btnSuggestions.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {//���ǹ�ưŬ���̺�Ʈ
				SuggestionGui frame = new SuggestionGui();
				frame.setVisible(true);
			}
		});
		btnSuggestions.setBounds(189, 15, 125, 29);
		contentPane.add(btnSuggestions);
		
		JLabel lblPoint = new JLabel("\uD3EC\uC778\uD2B8 :");
		lblPoint.setBounds(413, 19, 78, 21);
		contentPane.add(lblPoint);
		
		pointField = new JTextField();//����Ʈ�ؽ�Ʈ�ʵ�
		pointField.setEditable(false);
		pointField.setBounds(486, 16, 125, 27);
		contentPane.add(pointField);
		pointField.setColumns(10);
		
		JLabel lblId = new JLabel("ID :");
		lblId.setBounds(641, 19, 78, 21);
		contentPane.add(lblId);
		
		idField = new JTextField();//id�ؽ�Ʈ�ʵ�
		idField.setEditable(false);
		idField.setBounds(673, 16, 156, 27);
		contentPane.add(idField);
		idField.setColumns(10);
		
		JButton btnLogout = new JButton("\uB85C\uADF8\uC544\uC6C3");//�α׾ƿ���ư
		btnLogout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {//�α׾ƿ���ưŬ���̺�Ʈ
			
			}
		});
		btnLogout.setBounds(874, 15, 125, 29);
		contentPane.add(btnLogout);
		
		JScrollPane treeField = new JScrollPane();
		treeField.setBounds(37, 59, 217, 534);
		contentPane.add(treeField);
		
		JTree kategoryTree = new JTree();//ī�װ���Ʈ��
		kategoryTree.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent ago0) {//Ʈ����带 ������ �ش�ī�װ����� å�� å���̺��� ���
				JTree tree = (JTree) ago0.getSource();
				DefaultMutableTreeNode currentnode= (DefaultMutableTreeNode)tree.getLastSelectedPathComponent();
				
				bookTable.setValueAt(null, 0, 0);
				String pnode = currentnode.getParent().toString();
				
				Connection conn = null;
	    	    Statement stmt = null;
				 try{Class.forName(JDBC_DRIVER);
					conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
					stmt = conn.createStatement();
					
					System.out.println(pnode);System.out.println(currentnode);
		    	      String sql = "select * from goods where kid = ( select kid from kategorie where kname =\""+pnode+"\" and ksub =\""+currentnode+"\")";
		    	      ResultSet rs = stmt.executeQuery(sql);
		    	      int counter = 0;
		    	      while(rs.next()) {
		    	    	  bookTable.setValueAt(null, counter+1, 0);
		    	    	  
		    	    	  String name = rs.getString("gname");
		    	    	  String seller = rs.getString("seller");
		    	    	  System.out.println(counter+" "+name);
		    	    	  bookTable.setValueAt(name, counter, 0);
		    	    	  bookTable.setValueAt(seller,counter,1);

		    	    	  counter++;
		    	    	  }
						rs.close();
						stmt.close();
						conn.close();
					} catch(Exception e){
								//���� �߻� �� ó���κ�

					} finally { //���ܰ� �ֵ� ���� ������ ����
						try{
							if(stmt!=null)
								stmt.close();
						}catch(SQLException ex1){
							//
						}
								
						try{
							if(conn!=null)
								conn.close();
						}catch(SQLException ex1){
							//
						}
					}
			}
		});
		
		kategoryTree.setModel(new DefaultTreeModel(
				new DefaultMutableTreeNode("kategorie") {//ī�װ���Ʈ�� ��� �����
					{
						Connection conn = null;
					    Statement stmt = null;
					     
					    try{
							Class.forName(JDBC_DRIVER);
							conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
							stmt = conn.createStatement();

					      String sql = "select distinct kname from kategorie";
					      ResultSet rs = stmt.executeQuery(sql);
					      
					DefaultMutableTreeNode node_1;
					      while(rs.next())
					      {
					    	  String dept = rs.getString("kname");
						      node_1 = new DefaultMutableTreeNode(dept);
						      
						    	  node_1.add(new DefaultMutableTreeNode("comeng"));
						    	  node_1.add(new DefaultMutableTreeNode("eleceng"));

						      add(node_1);
					      }
					      
					      rs.close();
							stmt.close();
							conn.close();
						} catch(Exception e){
									//���� �߻� �� ó���κ�

						} finally { //���ܰ� �ֵ� ���� ������ ����
							try{
								if(stmt!=null)
									stmt.close();
							}catch(SQLException ex1){
								//
							}
									
							try{
								if(conn!=null)
									conn.close();
							}catch(SQLException ex1){
								//
							}
						}
					}
				}
			));
		
		treeField.setViewportView(kategoryTree);
		
		JScrollPane bookField = new JScrollPane();
		bookField.setBounds(271, 59, 352, 483);
		contentPane.add(bookField);
		
		bookTable = new JTable();//å���̺�
		bookTable.addMouseListener(new MouseAdapter() {//å���̺� ���콺Ŭ���̺�Ʈ
			@Override
			public void mouseClicked(MouseEvent arg0) 
			{
				int row = bookTable.getSelectedRow();
				Object booktitle = bookTable.getValueAt(row, 0);
				Object sellerID = bookTable.getValueAt(row, 1);
				
				BuyGui frame = new BuyGui(booktitle,sellerID);
				frame.setVisible(true);
				
			}
		});
		bookTable.setFillsViewportHeight(true);
		bookTable.setRowHeight(40);
		bookTable.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
			},
			new String[] {
				"\uCC45\uC774\uB984", "\uD310\uB9E4\uC790"
			}
		));
		bookField.setViewportView(bookTable);
		
		JLabel lblCart = new JLabel("\uC7A5\uBC14\uAD6C\uB2C8");
		lblCart.setBounds(800, 68, 78, 21);
		contentPane.add(lblCart);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(641, 92, 358, 345);
		contentPane.add(scrollPane);
		
		cartTable = new JTable();//��ٱ������̺�
		cartTable.setFillsViewportHeight(true);
		cartTable.setRowHeight(35);
		cartTable.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
			},
			new String[] {
				"\uD56D\uBAA9\uC0AD\uC81C", "\uCC45\uC774\uB984", "\uD310\uB9E4\uC790", "\uAC00\uACA9"
			}
		));
		scrollPane.setViewportView(cartTable);
		
		JLabel lblTotall = new JLabel("\uCD1D \uAC00\uACA9 :");
		lblTotall.setBounds(762, 452, 78, 21);
		contentPane.add(lblTotall);
		
		totallField = new JTextField();//�Ѱ����ؽ�Ʈ�ʵ�
		totallField.setEditable(false);
		totallField.setBounds(843, 449, 156, 27);
		contentPane.add(totallField);
		totallField.setColumns(10);
		
		JButton btnDelete = new JButton("\uD56D\uBAA9\uC0AD\uC81C");//�׸������ư
		btnDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {//�׸������ưŬ���̺�Ʈ
			}
		});
		btnDelete.setBounds(874, 489, 125, 29);
		contentPane.add(btnDelete);
		
		JButton btnBuy = new JButton("\uAD6C\uB9E4");//���Ź�ư
		btnBuy.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {//���Ź�ưŬ���̺�Ʈ
			}
		});
		btnBuy.setBounds(874, 533, 125, 29);
		contentPane.add(btnBuy);
		
		searchField = new JTextField();//�˻��ؽ�Ʈ�ʵ�
		searchField.setBounds(271, 557, 231, 27);
		contentPane.add(searchField);
		searchField.setColumns(10);
		
		JButton btnSearch = new JButton("\uAC80\uC0C9");//�˻���ư
		btnSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {//�˻���ưŬ���̺�Ʈ
				String serch = searchField.getText();
				
				Connection conn = null;
			    Statement stmt = null;
			     
			    try{
					Class.forName(JDBC_DRIVER);
					conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
					stmt = conn.createStatement();

			      String sql = "select gname from goods where '"+serch+"'" ;
			      ResultSet rs = stmt.executeQuery(sql);
			      int counter =0;
			      while(rs.next())
			      {
			    	  String gname = rs.getString("serch");
			    	  
			    	  bookTable.setValueAt(gname, counter, 0);
				      }
			      
			      rs.close();
					stmt.close();
					conn.close();
				} catch(Exception ex){
							//���� �߻� �� ó���κ�

				} finally { //���ܰ� �ֵ� ���� ������ ����
					try{
						if(stmt!=null)
							stmt.close();
					}catch(SQLException ex1){
						//
					}
							
					try{
						if(conn!=null)
							conn.close();
					}catch(SQLException ex1){
						//
					}
				}
			}	
		});
		btnSearch.setBounds(498, 557, 125, 29);
		contentPane.add(btnSearch);
	}
}