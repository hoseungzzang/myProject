package projectTT;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.CardLayout;


public class MasterGui extends JFrame {

	private JPanel contentPane;
	private JTextField Idfield;
	private JTable Sell;
	private JTable User;
	private JTable RE;
	
	// ��Ʈ ���úκ�
	JPanel chart = new JPanel();
	JScrollPane SPane = new JScrollPane();	//�Խù� ���̺�
	JScrollPane SPane2 = new JScrollPane();	//����� ���� ���̺�
	JScrollPane SPane3 = new JScrollPane();	//��� ���� ���̺�
	
	private final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver"; //����̹�
	private final String DB_URL = "jdbc:mysql://localhost/booksell?serverTimezone = UTC"; //������ DB
	
	private final String USER_NAME = "root"; //DB�� ������ �����
	private final String PASSWORD = "admin"; //������� ��й�ȣ
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MasterGui frame = new MasterGui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MasterGui() {
		setVisible(true);
		//����
		setTitle("������ �ܼ�");
		setBounds(100, 100, 870, 560);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel IDlabel = new JLabel("ID :");
		IDlabel.setBounds(518, 19, 78, 21);
		contentPane.add(IDlabel);
		
		
		Idfield = new JTextField();		//ID �ʵ�(������ ID ǥ�õ�)
		Idfield.setEditable(false);
		Idfield.setBounds(551, 16, 156, 27);
		contentPane.add(Idfield);
		Idfield.setColumns(10);
		
		JButton LogoutBtn = new JButton("LOGOUT");	//�α׾ƿ�
		LogoutBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				System.exit(0);
			}
		});
		LogoutBtn.setBounds(721, 12, 105, 34);
		contentPane.add(LogoutBtn);
		
		
		JButton SellBuy = new JButton("�Խù� ����");	//�Խù�����
		SellBuy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				chart.add(SPane2, "����� ����");
				chart.add(SPane3, "��� ����");
				
				Connection conn = null;
			    Statement stmt = null;
			    
				try{Class.forName(JDBC_DRIVER);
				conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
				stmt = conn.createStatement();
			
				 String sql = "select gname,price,seller from goods";
			     ResultSet rs = stmt.executeQuery(sql);
			     int counter = 0;
			      while(rs.next())
			      {
			    	  Sell.setValueAt(null, counter+1, 0);
			    	  
			    	  String gname = rs.getString("gname");
			    	  String price = rs.getString("price");
			    	  String user = rs.getString("seller");

			    	  System.out.println(counter+gname+price+user);
	    	    	  Sell.setValueAt(gname, counter, 0);
	    	    	  Sell.setValueAt(price, counter, 0);
	    	    	  Sell.setValueAt(user,counter,1);

	    	    	  counter++;
	    	    	  
				   }
			      
			      rs.close();
					stmt.close();
					conn.close();
				} catch(Exception e){
					//���� �߻� �� ó���κ�

		}finally { //���ܰ� �ֵ� ���� ������ ����
			try{
				if(stmt!=null)
					stmt.close();
			}catch(SQLException ex1){
				//
			}
					
			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException ex1){
				//
			}
		}				
			}
		});
		
		SellBuy.setBounds(56, 107, 120, 42);
		contentPane.add(SellBuy);
		
		JButton UserIf = new JButton("����� ����");	//����� ����
		UserIf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				chart.add(SPane, "�Խù� ����");
				chart.add(SPane3, "��� ����");
				
				Connection conn = null;
			    Statement stmt = null;
			    
				try{Class.forName(JDBC_DRIVER);
				conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
				stmt = conn.createStatement();
			
				 String sql = "select uname,ublock from user";
			     ResultSet rs = stmt.executeQuery(sql);
			     int counter = 0;
			      while(rs.next())
			      {
			    	  User.setValueAt(null, counter+1, 0);
			    	  
			    	  String user = rs.getString("uname");
			    	  String card = rs.getString("ublock");
			    	  

			    	  System.out.println(counter+user+card);
			    	  User.setValueAt(user, counter, 0);
			    	  User.setValueAt(card, counter, 0);
	    	    	  

	    	    	  counter++;
	    	    	  
				   }
			      
			      rs.close();
					stmt.close();
					conn.close();
				} catch(Exception ex){
					//���� �߻� �� ó���κ�

		}finally { //���ܰ� �ֵ� ���� ������ ����
			try{
				if(stmt!=null)
					stmt.close();
			}catch(SQLException ex1){
				//
			}
					
			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException ex1){
				//
			}
		}		
				
				
			}
		});
		UserIf.setBounds(56, 238, 120, 42);
		contentPane.add(UserIf);

		
		JButton reply = new JButton("��� ����");
		reply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				chart.add(SPane, "�Խù� ����");
				chart.add(SPane2, "����� ����");
				
				Connection conn = null;
			    Statement stmt = null;
			    
				try{Class.forName(JDBC_DRIVER);
				conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
				stmt = conn.createStatement();
			
				 String sql = "select stext,userID from suggestion";
			     ResultSet rs = stmt.executeQuery(sql);
			     int counter = 0;
			      while(rs.next())
			      {
			    	  RE.setValueAt(null, counter+1, 0);
			    	  
			    	  String text = rs.getString("stext");
			    	  String userID = rs.getString("userID");
			    	  

			    	  System.out.println(counter+text+userID);
			    	  RE.setValueAt(text, counter, 0);
			    	  RE.setValueAt(userID, counter, 0);
	    	    	  

	    	    	  counter++;
	    	    	  
				   }
			      
			      rs.close();
					stmt.close();
					conn.close();
				} catch(Exception ex){
					//���� �߻� �� ó���κ�

		}finally { //���ܰ� �ֵ� ���� ������ ����
			try{
				if(stmt!=null)
					stmt.close();
			}catch(SQLException ex1){
				//
			}
					
			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException ex1){
				//
			}
		}
			}
		});
			
		reply.setBounds(56, 363, 120, 42);
		contentPane.add(reply);

		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(221, 385, 617, 104);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton delete = new JButton("����");	//�Խù� ���� üũ ���� ������ư
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		delete.setBounds(498, 12, 105, 27);
		panel.add(delete);
		
		
		//ȭ�� ���� ��Ʈ
		chart.setBounds(221, 63, 617, 320);
		contentPane.add(chart);
		chart.setLayout(new CardLayout(0, 0));
		chart.add(SPane, "�Խù� ����");
		
		//�Խù� ����
		Sell = new JTable();
		SPane.setViewportView(Sell);
		Sell.setFillsViewportHeight(true);
		Sell.setRowHeight(35);
		Sell.setModel(new DefaultTableModel(
				new Object[][] {
					{null, null, null, null},
					{null, null, null, null},
					{null, null, null, null},
					{null, null, null, null},
					{null, null, null, null},
					{null, null, null, null},
					{null, null, null, null},
					{null, null, null, null},
					{null, null, null, null},
				},
				new String[] {
					"���� üũ", "å�̸�", "����", "�����ID"
				}
			));	
		
		SPane2 = new JScrollPane();
		chart.add(SPane2, "����� ����");
		
		//����� ����
		User = new JTable();
		SPane2.setViewportView(User);
		User.setFillsViewportHeight(true);
		User.setRowHeight(35);
		User.setModel(new DefaultTableModel(
				new Object[][] {
					{null, null, null, null},
					{null, null, null, null},
					{null, null, null, null},
					{null, null, null, null},
					{null, null, null, null},
					{null, null, null, null},
					{null, null, null, null},
					{null, null, null, null},
					{null, null, null, null},
				},
				new String[] {
					"���� üũ", "�����ID", "��� Ƚ��", "����"
				}
			));	

		SPane3 = new JScrollPane();
		chart.add(SPane3, "��۰���");
		
		//��۰���
		RE = new JTable();
		SPane3.setViewportView(RE);
		RE.setFillsViewportHeight(true);
		RE.setRowHeight(35);
		RE.setModel(new DefaultTableModel(
				new Object[][] {
					{null, null, null},
					{null, null, null},
					{null, null, null},
					{null, null, null},
					{null, null, null},
					{null, null, null},
					{null, null, null},
					{null, null, null},
					{null, null, null},
				},
				new String[] {
					"���� üũ", "����", "�����ID"
				}
			));	
	}
}

