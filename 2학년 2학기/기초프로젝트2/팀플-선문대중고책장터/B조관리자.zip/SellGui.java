import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

//�Ǹ��ϱ� gui
public class SellGui extends JFrame {

	private JPanel contentPane;
	private JTextField booktitleField;
	private JLabel lblBooktitle;
	private JLabel lblSeller;
	private JLabel lblPrice;
	
	private final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver"; //����̹�
	private final String DB_URL = "jdbc:mysql://localhost/booksell?serverTimezone = UTC"; //������ DB
	
	private final String USER_NAME = "Lee"; //DB�� ������ ����� �̸�
	private final String PASSWORD = "1111"; //������� ��й�ȣ
	
	private JTextField txtSeller;
	private JTextField txtPrice;
	private JButton btnNewButton_2;
	private JTextField textField;

	/**
	 * Launch the application.
	 */	
	MainGui main = new MainGui();
	
	/**
	 * Create the frame.
	 */
	public SellGui() {
		setResizable(false);
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent arg0) {
				
			}
		});
		
		setTitle("\uD310\uB9E4\uD558\uAE30");
		setBounds(100, 100, 516, 521);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBookintel = new JLabel("\uC815\uBCF4");
		lblBookintel.setBounds(31, 239, 78, 21);
		contentPane.add(lblBookintel);
		
		JLabel lblTitle = new JLabel("\uD310\uB9E4\uD558\uAE30");
		lblTitle.setBounds(208, 15, 78, 21);
		contentPane.add(lblTitle);
		
		booktitleField = new JTextField("bookname");
		booktitleField.setBounds(321, 52, 156, 27);
		contentPane.add(booktitleField);
		booktitleField.setColumns(10);
		
		lblBooktitle = new JLabel("\uCC45\uC81C\uBAA9");
		lblBooktitle.setBounds(226, 55, 78, 21);
		lblBooktitle . setHorizontalAlignment(lblBooktitle.CENTER);
		contentPane.add(lblBooktitle);
		
		lblSeller = new JLabel("\uD310\uB9E4\uC790");
		lblSeller . setHorizontalAlignment(lblSeller.CENTER);
		lblSeller.setBounds(226, 96, 78, 21);
		contentPane.add(lblSeller);
		
		lblPrice = new JLabel("\uAC00\uACA9");
		lblPrice.setBounds(226, 132, 78, 21);
		lblPrice . setHorizontalAlignment(lblPrice.CENTER);
		contentPane.add(lblPrice);
		
		JTextArea bookintelArea = new JTextArea();
		bookintelArea.setLineWrap(true);
		bookintelArea.setBounds(31, 266, 279, 182);
		contentPane.add(bookintelArea);
		
		txtSeller = new JTextField();
		txtSeller.setText("seller");
		txtSeller.setBounds(321, 93, 156, 27);
		contentPane.add(txtSeller);
		txtSeller.setColumns(10);
		
		txtPrice = new JTextField();
		txtPrice.setText("price");
		txtPrice.setBounds(321, 129, 156, 27);
		contentPane.add(txtPrice);
		txtPrice.setColumns(10);
		
		btnNewButton_2 = new JButton("����");//�����ư
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Connection conn = null; 
				Statement stmt = null; 
				
				String bookTitle = booktitleField.getText();
				String seller = txtSeller.getText();
				String price = txtPrice.getText();
		
			    	try{
						Class.forName(JDBC_DRIVER);
						conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
						stmt = conn.createStatement();
						
						int counter = 0;	//gid ����
						
						String sql; //SQL���� ������ String
						sql = "INSERT INTO goods ("
								+"gid"
								+"gname" 
								+"kid" 
								+"price" 
								+"seller)" 
								+ "values('"+counter+ "','"
				                +bookTitle+ "','"
								+textField.getText()+ "','"
								+price+ "','"
				                +seller+"')";
						counter++;
						
						ResultSet rs = stmt.executeQuery(sql); //SQL���� �����Ͽ� ����
						System.out.println(sql);


						while(rs.next()){
							bookTitle = rs.getString("gname");
							seller= rs.getString("uname");
							price = rs.getString("price");

							System.out.println(bookTitle);
							System.out.println(seller);
							System.out.println(price);

						}

						rs.close();
						stmt.close();
						conn.close();
			    	} catch(Exception ex){
			    		//���� �߻� �� ó���κ�

			    	} finally { //���ܰ� �ֵ� ���� ������ ����
			    		try{
			    			if(stmt!=null)
			    				stmt.close();
			    		}catch(SQLException ex1){
			    			//
			    		}

			    		try{
			    			if(conn!=null)
			    				conn.close();
			    		}catch(SQLException ex1){
			    			//
			    		}
			    		

			    	}
			
			}
		});
		btnNewButton_2.setBounds(335, 419, 125, 29);
		contentPane.add(btnNewButton_2);
		
		JTextArea pictureArea = new JTextArea();
		pictureArea.setEditable(false);
		pictureArea.setBounds(43, 54, 156, 155);
		contentPane.add(pictureArea);
		
		JLabel label = new JLabel("\uC885\uB958");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(226, 170, 78, 21);
		contentPane.add(label);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText((String)comboBox.getSelectedItem());;	
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"\uC120\uD0DD\uD558\uAE30", "\uC778\uBB38\uB300", "\uACF5\uACFC\uB300"}));
		comboBox.setBounds(321, 168, 156, 24);
		contentPane.add(comboBox);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(321, 168, 156, 24);
		contentPane.add(textField);
		textField.setColumns(10);
	
	}
}
