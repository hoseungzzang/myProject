import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class LoginChat extends JFrame{

	private JScrollPane SP;
	private JTextArea Msg,Memberlist;
	private JLabel lblNewLabel,lblMember;
	private JTextField Sendtext;
	private JButton send;
	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public LoginChat() {
		setTitle("\uC2E4\uC2DC\uAC04 \uBB38\uC758");
			/**
	 * Initialize the contents of the frame.
	 */
	
		
		setBounds(100, 100, 470, 495);
		getContentPane().setLayout(null);
		
		SP = new JScrollPane();
		SP.setBounds(14, 42, 295, 351);
		getContentPane().add(SP);
		
		Msg = new JTextArea();
		SP.setViewportView(Msg);
		Msg.setEditable(false);
		Msg.setLineWrap(true);
		
		Memberlist = new JTextArea();
		Memberlist.setLineWrap(true);
		Memberlist.setEditable(false);
		Memberlist.setBounds(323, 43, 115, 351);
		getContentPane().add(Memberlist);
		
		lblNewLabel = new JLabel("MessageBox");
		lblNewLabel.setBounds(14, 12, 93, 18);
		getContentPane().add(lblNewLabel);
		
		lblMember = new JLabel("Members");
		lblMember.setBounds(323, 12, 93, 18);
		getContentPane().add(lblMember);
		
		Sendtext = new JTextField();
		Sendtext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String User = null;
				
				String text = Sendtext.getText();
				Msg.append(User +" : "+ text + "\n");
				Sendtext.selectAll();
				Sendtext.setText("");
				Msg.setCaretPosition(Msg.getDocument().getLength());
				
			}
		});
		Sendtext.setBounds(14, 411, 295, 24);
		getContentPane().add(Sendtext);
		Sendtext.setColumns(10);
		
		send = new JButton("\uC804\uC1A1");
		send.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String User = null;
				
				String text = Sendtext.getText();
				Msg.append(User +" : "+ text + "\n");
				Sendtext.selectAll();
				Sendtext.setText("");
				Msg.setCaretPosition(Msg.getDocument().getLength());
			}
		});
		send.setBounds(323, 410, 115, 27);
		getContentPane().add(send);
	}

}
