import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTabbedPane;
//���ǰԽ��� ���,����,���� gui
public class Comment extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	
	private final String JDBC_DRIVER = "com.mysql.jdbc.Driver"; //����̹�
	private final String DB_URL = "jdbc:mysql://localhost/booksell?serverTimezone = UTC"; //������ DB ����
		
	private final String USER_NAME = "Lee"; //DB�� ������ ����� �̸��� ����� ����
	private final String PASSWORD = "1111"; //������� ��й�ȣ�� ����� ����

	/**
	 * Launch the application.
	 */
	MainGui main = new MainGui();
	private JTextField textField_1;
	
	//	public static void main(String[] args) {
//		try {
//			Comment dialog = new Comment();
//			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
//			dialog.setVisible(true);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	/**
	 * Create the dialog.
	 */
	public Comment(Object preID,int BuySell, Object s) {
		setTitle("comment");
		setBounds(100, 100, 450, 256);
		getContentPane().setLayout(new BorderLayout());
		{
			JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
			getContentPane().add(tabbedPane, BorderLayout.CENTER);
			tabbedPane.addTab("\uB313\uAE00", null, contentPanel, null);
			contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
			contentPanel.setLayout(null);
			{
				textField = new JTextField();
				textField.setBounds(17, 51, 394, 27);
				contentPanel.add(textField);
				textField.setColumns(10);
			}
			{
				JLabel lblComment = new JLabel("\uB313\uAE00\uB2EC\uAE30");
				lblComment.setBounds(17, 15, 78, 21);
				contentPanel.add(lblComment);
			}
			{

				JLabel lblNewLabel = new JLabel((String) s);
				lblNewLabel.setBounds(130, 15, 78, 21);
				contentPanel.add(lblNewLabel);
			}
			{
				JLabel lblNewLabel = new JLabel("");
				lblNewLabel.setBounds(130, 15, 78, 21);
				contentPanel.add(lblNewLabel);
			}
			{
				JButton okButton = new JButton("\uC785\uB825");
				okButton.setBounds(246, 117, 69, 29);
				contentPanel.add(okButton);
				okButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {//����Է¹�ư
						Connection conn = null;
					    Statement stmt = null;
					    int MaxID = 0;
					    
					    try{
					    	Class.forName(JDBC_DRIVER);
							conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
							stmt = conn.createStatement();

					      String sql = "select max(sid) from suggestion where buysell ="+BuySell;
					      ResultSet rs = stmt.executeQuery(sql);
					      while(rs.next()) {

					    	 MaxID = rs.getInt("max(sid)");
					    	  System.out.println(MaxID);

					    	 
					      }

							
					      stmt.close();
					      conn.close();
					       
					    }
					    catch(ClassNotFoundException e){
					      System.out.println("����̹� �ε� ����");
					    }
					    catch(SQLException e){
					      System.out.println("����: " + e);
					    }
					    finally{
					      try{
					        if( conn != null && !conn.isClosed()){
					          conn.close();
					        }
					      }
					      catch( SQLException e){
					        e.printStackTrace();
					      }
					    }

						try{
							Class.forName(JDBC_DRIVER);
							conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
							stmt = conn.createStatement();
							MaxID++;
							String text = textField.getText();

							String sql = "insert into suggestion(sid, stext, userid, buysell,sgroup, sdepth) values ("+MaxID+",\"��"+text+"\",0,"+BuySell+","+preID+", 1);";//����id �ϴ� 0���� �߽��ϴ�
							System.out.println(sql);
							stmt.executeUpdate(sql);


							stmt.close();
							conn.close();
				       
				    }
				    catch(ClassNotFoundException e){
				      System.out.println("����̹� �ε� ����");
				    }
				    catch(SQLException e){
				      System.out.println("����: " + e);
				    }
				    finally{
				      try{
				        if( conn != null && !conn.isClosed()){
				          conn.close();
				        }
				      }
				      catch( SQLException e){
				        e.printStackTrace();
				      }
				    }
						
					setVisible(false);
					}
				});
				okButton.setActionCommand("OK");
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("\uCDE8\uC18C");
				cancelButton.setBounds(341, 117, 87, 29);
				contentPanel.add(cancelButton);
				cancelButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						setVisible(false);
					}
				});
				cancelButton.setActionCommand("Cancel");
			}
			{
				JPanel panel = new JPanel();
				tabbedPane.addTab("\uC218\uC815", null, panel, null);
				panel.setLayout(null);
				
				textField_1 = new JTextField();
				textField_1.setBounds(17, 47, 389, 27);
				panel.add(textField_1);
				textField_1.setColumns(10);
				
				JButton btnUpdate = new JButton("\uC218\uC815");
				btnUpdate.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {//������Ʈ��ư
						Connection conn = null;
					    Statement stmt = null;
					    
						try{
							Class.forName(JDBC_DRIVER);
							conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
							stmt = conn.createStatement();
							
							String text = textField_1.getText();

							String sql = "update suggestion set stext = \""+text+"\" where sid = "+preID;
							System.out.println(sql);
							stmt.executeUpdate(sql);


							stmt.close();
							conn.close();
				       
				    }
				    catch(ClassNotFoundException e){
				      System.out.println("����̹� �ε� ����");
				    }
				    catch(SQLException e){
				      System.out.println("����: " + e);
				    }
				    finally{
				      try{
				        if( conn != null && !conn.isClosed()){
				          conn.close();
				        }
				      }
				      catch( SQLException e){
				        e.printStackTrace();
				      }
				    }
						
					setVisible(false);
					
					}
				});
				btnUpdate.setBounds(182, 101, 87, 29);
				panel.add(btnUpdate);
				
				JButton btnNewButton = new JButton("\uCDE8\uC18C");
				btnNewButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						setVisible(false);

					}
				});
				btnNewButton.setBounds(286, 101, 87, 29);
				panel.add(btnNewButton);
				
				JLabel lblUpdate = new JLabel("\uC218\uC815");
				lblUpdate.setBounds(17, 15, 78, 21);
				panel.add(lblUpdate);
				
				JLabel lblNewLabel = new JLabel((String) s);
				lblNewLabel.setBounds(130, 15, 78, 21);
				panel.add(lblNewLabel);
			}
			{
				JPanel panel = new JPanel();
				tabbedPane.addTab("\uC0AD\uC81C", null, panel, null);
				panel.setLayout(null);
				{
					JButton btnDelete = new JButton("\uC0AD\uC81C");
					btnDelete.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent arg0) {//������ư
							Connection conn = null;
						    Statement stmt = null;
						    
							try{
								Class.forName(JDBC_DRIVER);
								conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
								stmt = conn.createStatement();
								
								String sql = "delete from suggestion where sid = "+preID+" and buysell ="+BuySell;
								System.out.println(sql);
								stmt.executeUpdate(sql);

								stmt.close();
								conn.close();
					       
					    }
					    catch(ClassNotFoundException e){
					      System.out.println("����̹� �ε� ����");
					    }
					    catch(SQLException e){
					      System.out.println("����: " + e);
					    }
					    finally{
					      try{
					        if( conn != null && !conn.isClosed()){
					          conn.close();
					        }
					      }
					      catch( SQLException e){
					        e.printStackTrace();
					      }
					    }
							
						setVisible(false);
						}
					});
					btnDelete.setBounds(140, 106, 125, 29);
					panel.add(btnDelete);
				}
				{
					JButton btnCancel = new JButton("\uCDE8\uC18C");
					btnCancel.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {					setVisible(false);

						}
					});
					btnCancel.setBounds(281, 106, 125, 29);
					panel.add(btnCancel);
				}
				
				JLabel lblDelete = new JLabel("\uC0AD\uC81C");
				lblDelete.setBounds(17, 15, 78, 21);
				panel.add(lblDelete);
				

				JLabel lblNewLabel = new JLabel((String) s);
				lblNewLabel.setBounds(130, 15, 78, 21);
				panel.add(lblNewLabel);
			}
		}
	}
	
	
	public void getSuggestion(Object s) {
		JLabel lblNewLabel = new JLabel((String) s);
		lblNewLabel.setBounds(130, 15, 78, 21);
		contentPanel.add(lblNewLabel);
	}
}
