import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

//�����ϱ� gui
public class BuyGui extends JFrame {

	private JPanel contentPane;
	private JTextField booktitleField;
	private JLabel lblBooktitle;
	private JLabel lblSeller;
	private JLabel lblPrice;
	
	private final String JDBC_DRIVER = "com.mysql.jdbc.Driver"; //����̹�
	private final String DB_URL = "jdbc:mysql://localhost/booksell?serverTimezone = UTC"; //������ DB ����
		
	private final String USER_NAME = "Lee"; //DB�� ������ ����� �̸��� ����� ����
	private final String PASSWORD = "1111"; //������� ��й�ȣ�� ����� ����
	
	

	/**
	 * Launch the application.
	 */
	MainGui main = new MainGui();
	private JTextField txtSeller;
	private JTextField txtPrice;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;


	/**
	 * Create the frame.
	 */
	public BuyGui(Object bookname, Object seller) {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent arg0) {
				Connection conn = null; 
				Statement stmt = null; 
				
				String bookTitle = null;
				String seller_1 = null;
				String price = null;
				
			    
			    	try{
						Class.forName(JDBC_DRIVER);
						conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
						stmt = conn.createStatement();
						
						String sql; //SQL���� ������ String
						sql = "SELECT gname, uname, price FROM goods,user where gname = \""+bookname+"\" and seller = "+seller+" and seller = uid";
						ResultSet rs = stmt.executeQuery(sql); //SQL���� �����Ͽ� ����
						System.out.println(sql);


						while(rs.next()){
							bookTitle = rs.getString("gname");
							seller_1 = rs.getString("uname");
							price = rs.getString("price");

							System.out.println(bookTitle);
							System.out.println(seller_1);
							System.out.println(price);

						}

						rs.close();
						stmt.close();
						conn.close();
			    	} catch(Exception e){
			    		//���� �߻� �� ó���κ�

			    	} finally { //���ܰ� �ֵ� ���� ������ ����
			    		try{
			    			if(stmt!=null)
			    				stmt.close();
			    		}catch(SQLException ex1){
			    			//
			    		}

			    		try{
			    			if(conn!=null)
			    				conn.close();
			    		}catch(SQLException ex1){
			    			//
			    		}

			    		booktitleField.setText(bookTitle);
			    		txtSeller.setText(seller_1);
			    		txtPrice.setText(price);

			    	}
			}
		});
		setTitle("\uAD6C\uB9E4\uD558\uAE30");
		setBounds(100, 100, 516, 521);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setResizable(false);
		
		JLabel lblBookintel = new JLabel("\uCC45\uC815\uBCF4");
		lblBookintel.setBounds(17, 267, 78, 21);
		contentPane.add(lblBookintel);
		
		JLabel lblTitle = new JLabel("\uAD6C\uB9E4\uD558\uAE30");
		lblTitle.setBounds(208, 15, 78, 21);
		contentPane.add(lblTitle);
		
		booktitleField = new JTextField("bookname");
		booktitleField.setBounds(321, 98, 156, 27);
		contentPane.add(booktitleField);
		booktitleField.setEditable(false);
		booktitleField.setColumns(10);
		
		lblBooktitle = new JLabel("\uCC45\uC81C\uBAA9");
		lblBooktitle.setBounds(226, 101, 78, 21);
		lblBooktitle . setHorizontalAlignment(lblBooktitle.CENTER);
		contentPane.add(lblBooktitle);
		
		lblSeller = new JLabel("\uD310\uB9E4\uC790");
		lblSeller . setHorizontalAlignment(lblSeller.CENTER);
		lblSeller.setBounds(226, 158, 78, 21);
		contentPane.add(lblSeller);
		
		lblPrice = new JLabel("\uAC00\uACA9");
		lblPrice.setBounds(226, 215, 78, 21);
		lblPrice . setHorizontalAlignment(lblPrice.CENTER);
		contentPane.add(lblPrice);
		
		JTextArea bookintelArea = new JTextArea();
		bookintelArea.setEditable(false);
		bookintelArea.setBounds(17, 268, 279, 182);
		contentPane.add(bookintelArea);
		
		txtSeller = new JTextField();
		txtSeller.setText("seller");
		txtSeller.setBounds(321, 155, 156, 27);
		contentPane.add(txtSeller);
		txtSeller.setEditable(false);
		txtSeller.setColumns(10);
		
		txtPrice = new JTextField();
		txtPrice.setText("price");
		txtPrice.setBounds(321, 212, 156, 27);
		contentPane.add(txtPrice);
		txtPrice.setEditable(false);
		txtPrice.setColumns(10);
		
		JButton btnNewButton = new JButton("\uBB38\uC758\uD558\uAE30");//�����ϱ��ư
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				LoginChat frame =new LoginChat();
				frame.setVisible(true);
			}
		});
		btnNewButton.setBounds(321, 263, 125, 29);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("\uC7A5\uBC14\uAD6C\uB2C8");//��ٱ��Ϲ�ư
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		btnNewButton_1.setBounds(321, 307, 125, 29);
		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("\uAD6C\uB9E4");//���Ź�ư
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		btnNewButton_2.setBounds(321, 351, 125, 29);
		contentPane.add(btnNewButton_2);
	
	}
}
