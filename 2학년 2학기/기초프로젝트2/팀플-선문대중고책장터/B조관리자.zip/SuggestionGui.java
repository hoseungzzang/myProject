import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;


//���ǰԽ��� gui
public class SuggestionGui extends JFrame{

	private JPanel contentPane;
	private JTextField textField;
	private JTable table;
	
	private final String JDBC_DRIVER = "com.mysql.jdbc.Driver"; //����̹�
	private final String DB_URL = "jdbc:mysql://localhost/booksell?serverTimezone = UTC"; //������ DB ����
		
	private final String USER_NAME = "Lee"; //DB�� ������ ����� �̸��� ����� ����
	private final String PASSWORD = "1111"; //������� ��й�ȣ�� ����� ����
	
	public static byte BuySell = 0;
	public static int MaxID = 0;

	/**
	 * Launch the application.
	 */
	MainGui main = new MainGui();

	/**
	 * Create the frame.
	 */
	public SuggestionGui() {
		setResizable(false);
		setTitle("\uAC74\uC758\uD558\uAE30");
		setBounds(100, 100, 637, 592);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSuggestion = new JLabel("\uAC74\uC758\uD558\uAE30");
		lblSuggestion.setBounds(273, 15, 78, 21);
		contentPane.add(lblSuggestion);
		
		JButton btnBuy = new JButton("\uAD6C\uB9E4");
		btnBuy.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {//���Ű��ǹ�ư�̺�Ʈ

				BuySell = 0;
//				int num = 0;
//				while (num < 12) {
//					table.setValueAt(null, num, 0);
//					System.out.println(num);
//					num++;
//				}
				for (int i = 0; i < table.getRowCount(); i++)
				      for(int j = 0; j < table.getColumnCount(); j++) { 
				          table.setValueAt("", i, j);}



				Connection conn = null;
			    Statement stmt = null;
			     
			    try{
			    	Class.forName(JDBC_DRIVER);
					conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
					stmt = conn.createStatement();

			      String sql = "select sid, stext,uname,sgroup from suggestion,user where buysell = 0 and userid = uid order by sgroup;";
			      ResultSet rs = stmt.executeQuery(sql);
			      
			      int counter = 0;
			      while(rs.next()) {

			    	  String text = rs.getString("stext");
			    	  String id = rs.getString("sid");
			    	  String user = rs.getString("uname");
			    	  System.out.println(text);

			    	  table.setValueAt(text, counter, 1);
			    	  table.setValueAt(id, counter, 0);
			    	  table.setValueAt(user,counter,2);

			    	  counter++;
			      }

			      
			      rs.close();
			      stmt.close();
			      conn.close();
			       
			    }
			    catch(ClassNotFoundException e){
			      System.out.println("����̹� �ε� ����");
			    }
			    catch(SQLException e){
			      System.out.println("����: " + e);
			    }
			    finally{
			      try{
			        if( conn != null && !conn.isClosed()){
			          conn.close();
			        }
			      }
			      catch( SQLException e){
			        e.printStackTrace();
			      }
			    }
				
				
			}
		});
		btnBuy.setBounds(17, 118, 125, 29);
		contentPane.add(btnBuy);
		
		JButton btnSell = new JButton("\uD310\uB9E4");
		btnSell.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {//�ǸŰ��ǹ�ư�̺�Ʈ
				BuySell = 1;
				
				for (int i = 0; i < table.getRowCount(); i++)
				      for(int j = 0; j < table.getColumnCount(); j++) { 
				          table.setValueAt("", i, j);}
				
				Connection conn = null;
			    Statement stmt = null;
			     
			    try{
			    	Class.forName(JDBC_DRIVER);
					conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
					stmt = conn.createStatement();

			      String sql = "select sid, stext,uname,sgroup from suggestion,user where buysell = 1 and userid = uid order by sgroup, sdepth;";
			      ResultSet rs = stmt.executeQuery(sql);
			      
			      int counter = 0;
			      while(rs.next()) {
			    	  
			    	  

			    	  String text = rs.getString("stext");
			    	  String id = rs.getString("sid");
			    	  String user = rs.getString("uname");
			    	  System.out.println(text);

			    	  table.setValueAt(text, counter, 1);
			    	  table.setValueAt(id, counter, 0);
			    	  table.setValueAt(user,counter,2);

			    	  counter++;
			    	  
			      }

			      
			      rs.close();
			      stmt.close();
			      conn.close();
			       
			    }
			    catch(ClassNotFoundException e){
			      System.out.println("����̹� �ε� ����");
			    }
			    catch(SQLException e){
			      System.out.println("����: " + e);
			    }
			    finally{
			      try{
			        if( conn != null && !conn.isClosed()){
			          conn.close();
			        }
			      }
			      catch( SQLException e){
			        e.printStackTrace();
			      }
			    }
			
			}
		});
		btnSell.setBounds(17, 201, 125, 29);
		contentPane.add(btnSell);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(169, 52, 416, 427);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {//���̺� Ŭ��
				Connection conn = null;
			    Statement stmt = null;
				
				int row = table.getSelectedRow();
//				int column = table.getSelectedColumn();
				Object coment = table.getValueAt(row, 1);
				Object id =  table.getValueAt(row, 0);
				System.out.println(id);
				System.out.println(id.getClass());
				
				Comment comnt = new Comment( id, BuySell,coment);
				comnt.getSuggestion(coment);
				comnt.setVisible(true);
				System.out.println(comnt.isVisible());
				//�ʱ�ȭ
				for (int i = 0; i < table.getRowCount(); i++)
				      for(int j = 0; j < table.getColumnCount(); j++) { 
				          table.setValueAt("", i, j);}
			}
		});
		table.setFillsViewportHeight(true);
		table.setRowHeight(40);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"\uAE00\uBC88\uD638", "\uAC8C\uC2DC\uBB3C", "\uC791\uC131\uC790"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table.getColumnModel().getColumn(0).setMaxWidth(80);
		table.getColumnModel().getColumn(2).setPreferredWidth(80);
		table.getColumnModel().getColumn(2).setMaxWidth(80);
		scrollPane.setViewportView(table);
		
		textField = new JTextField();
		textField.setBounds(169, 494, 285, 27);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnEnter = new JButton("\uD655\uC778");
		btnEnter.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {//�۾����ư�̺�Ʈ
			String text = textField.getText();
		
			Connection conn = null;
		    Statement stmt = null;
		    
		    try{
		    	Class.forName(JDBC_DRIVER);
				conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
				stmt = conn.createStatement();

		      String sql = "select max(sid) from suggestion where buysell ="+BuySell;
		      ResultSet rs = stmt.executeQuery(sql);
		      while(rs.next()) {

		    	 MaxID = rs.getInt("max(sid)");
		    	  System.out.println(MaxID);

		    	 
		      }

				
		      stmt.close();
		      conn.close();
		       
		    }
		    catch(ClassNotFoundException e){
		      System.out.println("����̹� �ε� ����");
		    }
		    catch(SQLException e){
		      System.out.println("����: " + e);
		    }
		    finally{
		      try{
		        if( conn != null && !conn.isClosed()){
		          conn.close();
		        }
		      }
		      catch( SQLException e){
		        e.printStackTrace();
		      }
		    }
		    
		    
		    try{
		    	Class.forName(JDBC_DRIVER);
				conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
				stmt = conn.createStatement();
				MaxID++;
		      String sql = "insert into suggestion(sid, stext, userid, buysell,sgroup, sdepth) values ("+MaxID+",\""+text+"\",0,"+BuySell+","+MaxID+", 0);";//����id �ϴ� 0���� �߽��ϴ�
		      System.out.println(sql);
			stmt.executeUpdate(sql);
		      
		      stmt.close();
		      conn.close();
		       
		    }
		    catch(ClassNotFoundException e){
		      System.out.println("����̹� �ε� ����");
		    }
		    catch(SQLException e){
		      System.out.println("����: " + e);
		    }
		    finally{
		      try{
		        if( conn != null && !conn.isClosed()){
		          conn.close();
		        }
		      }
		      catch( SQLException e){
		        e.printStackTrace();
		      }
		    }
			
		    for (int i = 0; i < table.getRowCount(); i++)
			      for(int j = 0; j < table.getColumnCount(); j++) { 
			          table.setValueAt("", i, j);}
			
		    
		    try{
		    	Class.forName(JDBC_DRIVER);
				conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
				stmt = conn.createStatement();

		      String sql = "select stext,uname from suggestion,user where buysell = "+BuySell+" and userid = uid;";
		      ResultSet rs = stmt.executeQuery(sql);
		      
		      int counter = 0;
		      while(rs.next()) {

		    	  String text_1 = rs.getString("stext");
		    	  System.out.println(text_1);

		    	  table.setValueAt(text_1, counter, 0);

		    	  counter++;
		      }

		      
		      rs.close();
		      stmt.close();
		      conn.close();
		       
		    }
		    catch(ClassNotFoundException e){
		      System.out.println("����̹� �ε� ����");
		    }
		    catch(SQLException e){
		      System.out.println("����: " + e);
		    }
		    finally{
		      try{
		        if( conn != null && !conn.isClosed()){
		          conn.close();
		        }
		      }
		      catch( SQLException e){
		        e.printStackTrace();
		      }
		    }
		    
			}
		});
		btnEnter.setBounds(460, 493, 125, 29);
		contentPane.add(btnEnter);
	}
}
